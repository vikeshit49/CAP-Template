# Product Requirements Document (PRD)
## Bookshop Management Application

### 1. Executive Summary

The Bookshop Management application is a comprehensive solution for managing books and authors in a bookshop environment. The system provides inventory management, pricing controls, search capabilities, author insights, and AI-powered book recommendations.

### 2. Product Overview

**Product Name:** Bookshop Management App  
**Target Users:** Bookshop staff and managers  
**Platform:** Web-based application  
**Technology Stack:** SAP CAP (Node.js), SAP UI5/Fiori, LiteLLM Proxy (Gemini 2.5)  

### 3. Business Objectives

- Streamline book and author management operations
- Enable efficient inventory tracking and control
- Provide intelligent search and filtering capabilities
- Deliver AI-powered book recommendations to enhance customer experience
- Offer insights into author performance and statistics

### 4. Core Features

#### 4.1 Book and Author Management
- Manage book catalog with comprehensive metadata
- Maintain author information and relationships
- Support for book-author associations

#### 4.2 Inventory Operations
- Increase stock levels for books
- Decrease stock levels for books
- Real-time inventory tracking

#### 4.3 Pricing and Discounts
- Apply percentage-based pricing discounts to books
- Discounts applied directly to book price (no separate discount entity)
- No validity window or fixed-amount discounts

#### 4.4 Search and Filtering
- Search books by title
- Search books by author
- Filter books by genre
- Combined search and filter capabilities

#### 4.5 Author Insights
- Author statistics computed on demand: authorName, totalBooks, totalStock, averagePrice
- Real-time author performance metrics

#### 4.6 AI-Powered Recommendations
- Book recommendations via LiteLLM proxy (OpenAI-compatible, routing to Gemini 2.5)
- Confidence scores for recommendations
- Brief reasoning for each recommendation
- Fallback mechanism for when the LLM proxy isn't running

### 5. User Interface Requirements

#### 5.1 Main Catalog Page
- Responsive master-detail layout
- Book listing with essential information
- Search and genre filter controls
- Navigation to detailed views

#### 5.2 Book Detail Page
- Comprehensive book information display
- Inventory management dialogs
- Discount application dialogs
- Recommendations panel

#### 5.3 Author Detail Page
- Author information and statistics
- Associated books listing
- Author performance insights

### 6. Technical Requirements

#### 6.1 Backend
- **Framework:** SAP CAP with Node.js runtime
- **API Standard:** OData v4
- **Core Entities:** Books and Authors
- **Custom Endpoints:** Inventory, pricing, search, statistics, recommendations

#### 6.2 Frontend
- **Framework:** SAP UI5/Fiori
- **Design:** Responsive master-detail layout
- **Browser Support:** Modern browsers (Chrome, Firefox, Safari, Edge)

#### 6.3 AI Integration
- **Service:** LiteLLM proxy (OpenAI-compatible API) routing to Gemini 2.5 for recommendations
- **Environment Variables:** LLM_PROXY_HOST, LLM_PROXY_PORT, LLM_MODEL, LLM_API_KEY
- **Protocol:** OpenAI chat completions format (POST /v1/chat/completions) — LiteLLM translates to the underlying model
- **Fallback:** Simple development fallback when LiteLLM proxy isn't running
- **Processing:** Generated per request, no caching

### 7. Data Requirements

#### 7.1 Data Model
- Books entity: title, author (single association to Authors), genre, price, stock, publishedDate
- Authors entity: name, dateOfBirth, nationality, books (association)
- One-to-many relationship (Author to Books)
- No ISBN, biography, or many-to-many authorship

#### 7.2 Seed Data
- Sample books for testing and demonstration
- Sample authors with associated books
- Realistic data for development and testing

### 8. Non-Functional Requirements

#### 8.1 Security
- Basic security expectations for web applications
- Secure API endpoints
- Input validation and sanitization

#### 8.2 Performance
- Reasonable response times for search operations
- Efficient data loading and pagination
- Optimized recommendation processing

#### 8.3 Browser Compatibility
- Support for modern web browsers
- Responsive design for various screen sizes

### 9. Testing Requirements

#### 9.1 Backend Testing
- API endpoint testing (happy path scenarios)
- Error handling validation
- Data integrity checks

#### 9.2 Frontend Testing
- UI flow testing
- User interaction validation
- Responsive design verification

### 10. Scope Constraints

**Explicitly Excluded:**
- Authentication and authorization systems
- Shopping cart functionality
- Order processing and payment systems
- User reviews and ratings
- Advanced dashboards and analytics (beyond author stats)
- Notification systems
- CI/CD pipeline setup
- Multi-tenancy support
- Additional AI features beyond recommendations

### 11. Assumptions and Open Questions

**Assumptions:**
- Single-tenant application deployment
- Percentage-based discounts only, applied directly to book price
- Author statistics computed on demand at request time
- Recommendations generated per request with no caching
- Minimal data model: Books with single author association, Authors with books association
- English-only error messages with standard HTTP status codes
- Stock validation: enforce addStock > 0 and prevent stock below zero
- Search/filtering: by-genre and by-author backend functions, free-text search handled in UI
- Simple recommendation algorithm for fallback mode

**Open Questions:**
- None remaining - all requirements clarified

### 12. Success Criteria

- Successful CRUD operations for books and authors
- Functional inventory increase/decrease operations
- Working search and filter capabilities
- AI recommendations with confidence scores and reasoning
- Responsive UI across target browsers
- All specified pages and dialogs operational
