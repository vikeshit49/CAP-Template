# Functional Requirements Document (FR)
## Bookshop Management Application

### 1. Introduction

This document defines the detailed functional requirements for the Bookshop Management application, specifying the exact behavior, data structures, API endpoints, and user interface flows.

### 2. Data Model Specifications

#### 2.1 Books Entity
```
Books {
  ID: UUID (Primary Key)
  title: String (required, max 200 chars)
  author_ID: UUID (Foreign Key to Authors, required)
  genre: String (required, max 50 chars)
  price: Decimal (required, precision 10,2)
  stock: Integer (required, default 0)
  publishedDate: Date (optional)
  createdAt: DateTime (auto-generated)
  updatedAt: DateTime (auto-generated)
}
```

#### 2.2 Authors Entity
```
Authors {
  ID: UUID (Primary Key)
  name: String (required, max 100 chars)
  dateOfBirth: Date (optional)
  nationality: String (optional, max 50 chars)
  createdAt: DateTime (auto-generated)
  updatedAt: DateTime (auto-generated)
}
```

**Data Model:** One-to-many relationship (Author to Books). No ISBN, biography, or many-to-many authorship. Minimal and focused design.

### 3. Backend API Specifications

#### 3.1 Standard OData v4 Endpoints

**Books Entity:**
- `GET /odata/v4/bookshop/Books` - List all books
- `GET /odata/v4/bookshop/Books(ID)` - Get specific book
- `POST /odata/v4/bookshop/Books` - Create new book
- `PATCH /odata/v4/bookshop/Books(ID)` - Update book
- `DELETE /odata/v4/bookshop/Books(ID)` - Delete book

**Authors Entity:**
- `GET /odata/v4/bookshop/Authors` - List all authors
- `GET /odata/v4/bookshop/Authors(ID)` - Get specific author
- `POST /odata/v4/bookshop/Authors` - Create new author
- `PATCH /odata/v4/bookshop/Authors(ID)` - Update author
- `DELETE /odata/v4/bookshop/Authors(ID)` - Delete author

#### 3.2 Custom Action Endpoints

**Inventory Management:**
```
POST /odata/v4/bookshop/Books(ID)/increaseStock
Body: { "quantity": number }
Response: { "success": boolean, "newStock": number, "message": string }

POST /odata/v4/bookshop/Books(ID)/decreaseStock
Body: { "quantity": number }
Response: { "success": boolean, "newStock": number, "message": string }
```

**Pricing Discounts:**
```
POST /odata/v4/bookshop/Books(ID)/applyDiscount
Body: { "discountPercent": number }
Response: { "success": boolean, "originalPrice": number, "discountedPrice": number, "message": string }
```

**Search and Filtering:**
```
GET /odata/v4/bookshop/Books/filterByGenre
Query Parameters:
  - genre: string (required)
  - $top: number (optional, default 20)
  - $skip: number (optional, default 0)
Response: Standard OData collection with Books entities

GET /odata/v4/bookshop/Books/filterByAuthor
Query Parameters:
  - authorId: UUID (required)
  - $top: number (optional, default 20)
  - $skip: number (optional, default 0)
Response: Standard OData collection with Books entities
```

**Note:** Free-text search (title/author) is handled in the UI, not as separate backend endpoints.

**Author Statistics:**
```
GET /odata/v4/bookshop/Authors(ID)/statistics
Response: {
  "authorName": string,
  "totalBooks": number,
  "totalStock": number,
  "averagePrice": number
}
```

**Note:** Statistics computed on demand at request time.

**Book Recommendations:**
```
GET /odata/v4/bookshop/Books(ID)/recommendations
Query Parameters:
  - count: number (optional, default 5, max 10)
Response: {
  "recommendations": [
    {
      "bookId": UUID,
      "title": string,
      "confidence": number (0-1),
      "reason": string (max 100 chars)
    }
  ],
  "source": string ("ai-core" | "fallback")
}
```

#### 3.3 Error Response Format
```
{
  "error": {
    "code": string,
    "message": string,
    "details": [
      {
        "code": string,
        "message": string,
        "target": string
      }
    ]
  }
}
```

**Assumption:** Standard HTTP status codes (200, 201, 400, 404, 500) with structured error messages.

### 4. AI Integration Specifications

#### 4.1 LiteLLM Proxy Configuration
- **Environment Variables:**
  - `LLM_PROXY_HOST`: LiteLLM proxy host URI (e.g., http://localhost)
  - `LLM_PROXY_PORT`: LiteLLM proxy port (e.g., 6655)
  - `LLM_MODEL`: Model identifier routed by LiteLLM (e.g., gemini-2.5)
  - `LLM_API_KEY`: API key for the LiteLLM proxy
- **Protocol:** OpenAI-compatible chat completions (POST /v1/chat/completions)

#### 4.2 Recommendation Logic
**When LiteLLM proxy is available:**
- Send book metadata and user preferences as a chat completions prompt to LiteLLM proxy
- Request structured JSON response with book recommendations, confidence scores, and reasoning
- Parse the LLM response into structured recommendation data

**Fallback mechanism (when LiteLLM proxy unavailable):**
- Use simple rule-based recommendations:
  - Same genre books
  - Same author books
  - Popular books (highest stock turnover)
- Generate basic confidence scores (0.3-0.7 range)
- Provide simple reasoning ("Same genre", "Same author", "Popular choice")

**Assumption:** LiteLLM proxy returns OpenAI-compatible chat completion responses; the app parses the assistant message content as JSON for recommendations.

### 5. Frontend UI Specifications

#### 5.1 Main Catalog Page

**Layout:**
- Master-detail responsive layout
- Master panel: Book list (left side, 40% width on desktop)
- Detail panel: Selected book details (right side, 60% width on desktop)
- Mobile: Stack layout with navigation

**Master Panel Components:**
- Search input field (placeholder: "Search by title or author...")
- Genre filter dropdown (All Genres, Fiction, Non-Fiction, Science, History, etc.)
- Book list with items showing:
  - Book title (truncated at 50 chars)
  - Author name(s)
  - Genre badge
  - Price with currency
  - Stock indicator (In Stock/Low Stock/Out of Stock)

**Detail Panel Components:**
- Book cover placeholder
- Full book information display
- Action buttons: "Manage Inventory", "Apply Discount"
- Recommendations section (collapsible)

#### 5.2 Book Detail Page

**Information Display:**
- Book title (h1)
- Author with link to Author Detail page
- Genre, Published Date
- Current price and stock level
- Publication information

**Action Dialogs:**

**Inventory Management Dialog:**
- Radio buttons: Increase Stock / Decrease Stock
- Number input: Quantity (min: 1, max: 1000)
- Current stock display
- Buttons: Cancel, Apply

**Discount Application Dialog:**
- Number input: Discount percentage (min: 1, max: 90)
- Price preview: Original → Discounted
- Buttons: Cancel, Apply

**Recommendations Panel:**
- Collapsible section
- List of recommended books with:
  - Book title (clickable)
  - Confidence bar (visual indicator)
  - Reason text
  - "View Details" link

#### 5.3 Author Detail Page

**Author Information:**
- Author name (h1)
- Birth date and nationality
- Author statistics summary

**Statistics Section:**
- Total books count
- Average book price
- Total stock across all books

**Associated Books:**
- Table/list of author's books
- Columns: Title, Genre, Price, Stock
- Clickable rows to navigate to Book Detail

### 6. Seed Data Specifications

#### 6.1 Sample Books (minimum 10 entries)
```
1. "The Great Gatsby" - F. Scott Fitzgerald - Fiction - $12.99 - Stock: 25
2. "To Kill a Mockingbird" - Harper Lee - Fiction - $14.50 - Stock: 18
3. "1984" - George Orwell - Science Fiction - $13.25 - Stock: 30
4. "Pride and Prejudice" - Jane Austen - Romance - $11.75 - Stock: 22
5. "The Catcher in the Rye" - J.D. Salinger - Fiction - $12.00 - Stock: 15
6. "Lord of the Flies" - William Golding - Fiction - $10.99 - Stock: 20
7. "Animal Farm" - George Orwell - Political Fiction - $9.50 - Stock: 35
8. "Brave New World" - Aldous Huxley - Science Fiction - $13.75 - Stock: 12
9. "The Hobbit" - J.R.R. Tolkien - Fantasy - $15.99 - Stock: 28
10. "Fahrenheit 451" - Ray Bradbury - Science Fiction - $11.25 - Stock: 16
```

#### 6.2 Sample Authors (minimum 8 entries)
```
1. F. Scott Fitzgerald - American novelist - Born: 1896
2. Harper Lee - American novelist - Born: 1926
3. George Orwell - British author - Born: 1903
4. Jane Austen - English novelist - Born: 1775
5. J.D. Salinger - American writer - Born: 1919
6. William Golding - British novelist - Born: 1911
7. Aldous Huxley - English writer - Born: 1894
8. J.R.R. Tolkien - English author - Born: 1892
```

### 7. Testing Specifications

#### 7.1 Backend API Testing

**Happy Path Scenarios:**
1. **CRUD Operations:**
   - Create book → Verify in database
   - Read book → Verify correct data returned
   - Update book → Verify changes persisted
   - Delete book → Verify removal

2. **Inventory Operations:**
   - Increase stock by 10 → Verify stock increased
   - Decrease stock by 5 → Verify stock decreased
   - Attempt to decrease stock below 0 → Verify error handling

3. **Search Operations:**
   - Search by title "Great" → Verify "The Great Gatsby" returned
   - Filter by genre "Fiction" → Verify only fiction books returned
   - Combined search and filter → Verify intersection results

4. **Recommendations:**
   - Request recommendations for book ID → Verify 5 recommendations returned
   - Verify confidence scores between 0-1
   - Verify reason strings present

**Error Scenarios:**
1. Invalid book ID → 404 Not Found
2. Missing required fields → 400 Bad Request
3. Invalid data types → 400 Bad Request
4. Decrease stock below zero → 400 Bad Request with specific error

#### 7.2 Frontend UI Testing

**Navigation Flows:**
1. Main Catalog → Select book → View details → Return to catalog
2. Main Catalog → Search for book → Select result → View details
3. Book Detail → Click author link → View Author Detail → Return

**Interaction Testing:**
1. **Search and Filter:**
   - Enter search term → Verify filtered results
   - Select genre filter → Verify genre-specific results
   - Clear filters → Verify all books shown

2. **Inventory Dialog:**
   - Open dialog → Select increase → Enter quantity → Apply → Verify success message
   - Open dialog → Select decrease → Enter invalid quantity → Verify error

3. **Discount Dialog:**
   - Open dialog → Enter discount → Preview price → Apply → Verify success

4. **Recommendations:**
   - Expand recommendations → Verify list displayed
   - Click recommendation → Navigate to recommended book

**Responsive Testing:**
- Desktop (1920x1080) → Verify master-detail layout
- Tablet (768x1024) → Verify responsive adjustments
- Mobile (375x667) → Verify stacked layout

### 8. Resolved Requirements and Assumptions

**Technical Assumptions:**
1. **Database:** SQLite for development, configurable for production
2. **Discount Type:** Percentage-based discounts only, applied directly to book price (no separate discount entity)
3. **Currency:** Single currency (USD) with $ symbol
4. **Date Format:** ISO 8601 format for all date fields
5. **Pagination:** Default page size of 20 items for all lists
6. **File Upload:** No book cover image upload functionality
7. **Concurrency:** Basic optimistic locking using updatedAt timestamps
8. **Author Statistics:** Computed on demand at request time (authorName, totalBooks, totalStock, averagePrice)
9. **Recommendations:** Generated per request with no caching
10. **Error Messages:** English only, standard simple error messages, no localization
11. **Search/Filtering:** By-genre and by-author backend functions; free-text search handled in UI
12. **Stock Validation:** No alerting; enforce addStock > 0 and prevent stock below zero

**Business Assumptions:**
1. **Stock Management:** Stock cannot go below zero; enforce positive addStock values
2. **Pricing:** Prices must be positive values
3. **Discounts:** Maximum discount of 90% to prevent negative prices
4. **Authors:** Authors can be created independently of books
5. **Search:** Case-insensitive search across title and author fields
6. **Data Model:** Minimal and focused - one-to-many Author to Books relationship
7. **AI Integration:** LiteLLM proxy (OpenAI-compatible) with env vars LLM_PROXY_HOST, LLM_PROXY_PORT, LLM_MODEL, LLM_API_KEY; simple dev fallback available

**Open Questions:**
- None remaining - all requirements clarified and integrated
