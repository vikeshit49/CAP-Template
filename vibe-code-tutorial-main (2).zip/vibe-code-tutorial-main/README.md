# Responsible Vibe Coding Tutorial using SAP AI Development Tools: Building a BookShop CAP App with Cline & LiteLLM

> ⚡ **Quick Start**: Already familiar with the basics? Skip to [Step 0: Configure MCP Servers](#️-step-0-configure-mcp-servers-recommended) to get started immediately.

## 🎯 What is Vibe Coding?

Vibe coding is a modern development approach where you collaborate with AI assistants to rapidly prototype and build applications through natural conversation and iterative refinement. Instead of writing every line of code manually, you "orchestrate" with AI to generate, refine, and optimize your codebase.

## 🛠️ Prerequisites (setup instructions below)
- VS Code installed
- Node.js (v18 or higher)
- Cline extension for VS Code
- LiteLLM proxy (setup instructions below in Part 1)

## 🛡️ What Does "Responsible" Mean in Vibe Coding?

<details>

The "responsible" in responsible vibe coding emphasizes that while AI accelerates development, you remain accountable for the quality, security, and maintainability of your code.

1. **You're the engineer, not the AI.** Own every line of code — including tests — and verify that it does what it claims. If you don't *understand* it, don't *ship* it.
2. **Test before you trust.** Use meaningful, verifiable tests to validate behavior — especially edge cases and failure modes.
3. **Design first, vibe second.** Think in terms of structure and intent before generating code. Creativity works best with constraints.
4. **Refactor with intent, not vibes.** Clean up iteratively, but with clear goals like readability, separation of concerns, or performance — not just "feels cleaner."
5. **Don't skip the boring parts.** Docs, validation, error handling, security — they're not optional. Prompt for them, review them, own them.
6. **Review "Security Requirements":** [Security Requirements](https://ai-docs.portal.hyperspace.tools.sap/llm-proxy/production-use/#security-requirements)

</details>

## 📦 What's in This Starter Repo

This is your **empty starting point**. Only the inputs and guardrails are provided — you'll use AI (Cline) to generate all the code.

```
vibe-code-tutorial/
├── docs/
│   ├── PRD.md                ← Product Requirements (your scope anchor)
│   └── FR.md                 ← Functional Requirements (your spec)
├── .clinerules/
│   ├── 01-project.md         ← Scope & planning guardrails
│   ├── 02-coding.md          ← Coding standards for the AI
│   └── 03-documentation.md   ← Doc & testing expectations
├── .vscode/                  ← VS Code workspace config
├── .env.example              ← LiteLLM proxy env var template
├── .gitignore
├── package.json              ← CAP dependencies (ready to npm install)
└── README.md                 ← You are here
```

## 🏗️ What You'll Build (via AI prompts)

```
vibe-code-tutorial/
├── db/
│   ├── schema.cds                      ← Data model (Books + Authors)
│   └── data/
│       ├── my.bookshop-Authors.csv     ← Seed authors
│       └── my.bookshop-Books.csv       ← Seed books
├── srv/
│   ├── book-service.cds                ← Service definition
│   ├── book-service.js                 ← Service implementation
│   └── ai-service.js                   ← LiteLLM integration + fallback
├── app/
│   └── bookshop/
│       ├── index.html                  ← UI5 entry point
│       ├── Component.js                ← UI5 component
│       ├── manifest.json               ← App descriptor + routing
│       ├── model/models.js             ← Device model helper
│       ├── i18n/i18n.properties        ← UI labels
│       ├── css/style.css               ← Custom styles
│       ├── view/
│       │   ├── App.view.xml
│       │   ├── Main.view.xml
│       │   ├── BookDetail.view.xml
│       │   └── AuthorDetail.view.xml
│       └── controller/
│           ├── App.controller.js
│           ├── Main.controller.js
│           ├── BookDetail.controller.js
│           └── AuthorDetail.controller.js
└── TESTING_GUIDE.md                    ← Testing documentation
```

---

## ⚙️ Step 0: Configure MCP Servers (Recommended)

<details>
<summary><strong>Click to expand: MCP server setup for Cline</strong></summary>

MCP (Model Context Protocol) servers extend Cline with extra capabilities (docs lookup, SAP-specific knowledge, UI5/CAP tooling, filesystem access, etc.). Configure the ones relevant for this tutorial.

### Recommended MCP servers

| Server | Purpose | Repo |
|--------|---------|------|
| **Core** | | |
| **Context7** | Up-to-date docs lookup (any library) | [context7](https://github.com/upstash/context7) |
| **Playwright** | Browser automation and testing | [playwright](https://github.com/microsoft/playwright-mcp) |
| **SAP Platform** | | |
| **CAP MCP Server** | CAP project intelligence | [cap-js/mcp-server](https://github.com/cap-js/mcp-server) |
| **UI5 MCP Server** | UI5 framework helpers | [UI5/mcp-server](https://github.com/UI5/mcp-server) |
| **SAP Internal** | | |
| **SAPUI5 MCP Server** | SAPUI5-specific guidance | [PIRIN/sapui5-mcp-server](https://github.tools.sap/PIRIN/sapui5-mcp-server) |
| **Fiori Elements Brain** | Fiori Elements expert | [MCP-LABS/fiori-element-brain-mcp-stdio](https://github.tools.sap/MCP-LABS/fiori-element-brain-mcp-stdio) |

### How to configure

1. In VS Code, open Cline → **MCP Servers** → **Installed** → **Configure MCP Servers**. This opens `cline_mcp_settings.json`.
2. Paste the snippet below and adjust paths/tokens for your machine. Remove any servers you don't need.

```json
{
  "mcpServers": {
    "context7": {
      "command": "npx",
      "args": ["-y", "@upstash/context7-mcp", "--api-key", "<CONTEXT7_API_KEY>"]
    },
    "playwright": {
      "command": "npx",
      "args": ["-y", "@modelcontextprotocol/server-playwright"]
    },
    "cap-mcp-server": {
      "command": "npx",
      "args": ["-y", "@cap-js/mcp-server"]
    },
    "ui5-mcp-server": {
      "command": "npx",
      "args": ["-y", "@ui5/mcp-server"]
    },
    "sapui5-mcp-server": {
      "command": "node",
      "args": ["<ABSOLUTE_PATH>/sapui5-mcp-server/dist/index.js"]
    },
    "fiori-elements-brain": {
      "command": "node",
      "args": ["<ABSOLUTE_PATH>/fiori-element-brain-mcp-stdio/dist/index.js"]
    }
}
```

**Notes:**

- Replace `<ABSOLUTE_PATH>` with the full path to cloned SAP-internal MCP repos
- For SAP-internal MCPs (`sapui5-mcp-server`, `fiori-elements-brain`, `sap-help-portal`): clone each repo, run `npm install && npm run build`, then point `args` to its built `dist/index.js`. Follow each repo's README for tokens/env vars.
- `<CONTEXT7_API_KEY>` is optional; Context7 also works without it for many lookups.
- A ready-to-edit template lives at [`.vscode/cline_mcp_settings.json`](.vscode/cline_mcp_settings.json) — copy it into Cline's MCP settings file.
- After saving, Cline will auto-load the servers. Toggle them on/off via the MCP Servers panel.

### 🤖 Prompt: let AI configure MCPs for you

Don't want to hand-edit JSON? Paste the prompt below into **Cline** (or **Claude Desktop**) and let it configure + validate the MCP servers for you.

```
You are helping me set up MCP (Model Context Protocol) servers for this workspace.

Goal: Configure the following MCP servers and then validate that each one is reachable and responding.

Servers to configure (skip any I say I don't need):
1. context7         → npx -y @upstash/context7-mcp --api-key <CONTEXT7_API_KEY>
2. playwright       → npx -y @modelcontextprotocol/server-playwright
3. cap-mcp-server   → npx -y @cap-js/mcp-server
4. ui5-mcp-server   → npx -y @ui5/mcp-server
5. sapui5-mcp-server     → node <ABSOLUTE_PATH>/sapui5-mcp-server/dist/index.js
6. fiori-elements-brain  → node <ABSOLUTE_PATH>/fiori-element-brain-mcp-stdio/dist/index.js
7. sap-help-portal       → node <ABSOLUTE_PATH>/help-portal-mcp/dist/index.js

Steps:
1. Detect whether I'm using Cline or Claude Desktop and locate the correct MCP settings file:
   - Cline (VS Code): cline_mcp_settings.json (open via Cline → MCP Servers → Configure MCP Servers)
   - Claude Desktop:
       • macOS: ~/Library/Application Support/Claude/claude_desktop_config.json
       • Windows: %APPDATA%\Claude\claude_desktop_config.json
       • Linux:   ~/.config/Claude/claude_desktop_config.json
2. Ask me for any missing values: Context7 API key (optional), and absolute paths for any locally-built SAP MCP servers. Only include servers I have paths/keys for; mark the rest as "disabled": true.
3. Merge — do NOT overwrite — into the existing "mcpServers" object. Preserve any servers already configured.
4. Write the updated JSON, validate it parses, and show me a diff of what changed.
5. Validate each newly added server:
   - Confirm the command exists (e.g. `which npx`, `which node`).
   - For npx-based servers, do a dry-run install check (`npx -y <pkg> --help` or equivalent) and report success/failure per server.
   - For local node servers, verify the dist/index.js path exists and is readable.
   - In Cline: ask me to reload the MCP Servers panel and confirm each shows a green/connected status; list any that failed and suggest fixes.
   - In Claude Desktop: ask me to fully quit and relaunch Claude, then confirm the servers appear under the 🔌 menu.
6. Print a final summary table: server name | enabled | validation status | next step (if any).

Constraints:
- Do not invent package names — use exactly what I provided.
- Never commit secrets to git; if you detect this repo's git, ensure the settings file is outside the repo or gitignored.
- If a server requires extra env vars (e.g. SAP auth tokens), ask me first instead of guessing.
```

> Tip: After the AI applies the config, run a quick smoke test by asking Cline/Claude something like *"List the MCP tools available to you"* — every configured server should contribute tools.

</details>

---

## ✅ Define Scope Before You Code

**Purpose:** Align on scope and expectations up front. Use `docs/PRD.md` and `docs/FR.md` as the single source of truth before any coding.

### Plan before you code (Cline Plan mode)
- Confirm scope against `docs/PRD.md` and `docs/FR.md` (no new features/entities/pages)
- Restate the concrete goal of this step and its acceptance criteria
- Note validations, error behaviors, and edge cases to cover
- Define test/verification steps (curl/UI steps) you'll run after the edit
- Optional: specify relevant files for context
- Only then proceed to generate/edit code

### Project-specific rules (be explicit)
- Stay scope-locked to the PRD/FR. If something is unclear, propose the minimal assumption and add an "Open Questions" note, don't add features.
- Prefer clarity over cleverness. Name things explicitly, avoid magic.
- Keep UI5/Fiori UX consistent and OData v4 usage explicit.

## 📐 Set Guardrails with Cline Rules

This repo ships with `.clinerules/` pre-configured:

```
.clinerules/
├── 01-project.md        # Scope, PRD/FR guardrails, definition of done
├── 02-coding.md         # Naming, structure, error handling patterns
└── 03-documentation.md  # Docs expectations (README, /docs updates)
```

These are always active in your workspace. Use Cline's Rules popover to see and toggle them.

Learn more: [Cline Rules docs](https://docs.cline.bot/features/cline-rules)

---

## 📋 Tutorial Overview

This tutorial demonstrates how to build a complete book management CAP service with AI-powered recommendations through natural conversation with AI assistants. You'll learn how to effectively prompt AI to create enterprise-grade applications.

**⏱️ Total Time Estimate**: ~1.5 hours
### Part 1: Setting Up Your Environment (⏱️ ~10 minutes)

```sh
# Install CAP CLI globally
npm install -g @sap/cds-dk

# Navigate to the starter repo
cd vibe-code-tutorial

# Install dependencies
npm install

# **Required dev driver** — CAP 8 needs `sqlite3` for the in-memory dev DB
npm install --save-dev sqlite3

# Set up your environment
cp .env.example .env
# Edit .env with your LiteLLM proxy details
```

> 💡 **Gotcha:** if `cds-serve` fails with `Cannot find module 'sqlite3'`, you skipped the dev-driver install above.

**Example `.env` configuration (SAP Hyperspace AI local proxy):**

```sh
LLM_PROXY_HOST=http://localhost
LLM_PROXY_PORT=7676
LLM_MODEL=gpt-4.1-mini
LLM_API_KEY=<your-key-from-Hyperspace>
LLM_PROXY_PATH=/openai/v1/chat/completions
```

> 💡 For a vanilla LiteLLM proxy, set `LLM_PROXY_PATH=/v1/chat/completions`. The app falls back to a deterministic rule-based recommender if the proxy isn't reachable.

---

## 🚀 The Vibe Coding Dev Journey

### Part 2: Creating the Foundation — Data Model (⏱️ ~10-15 minutes)

**Goal**: Create a simple book management data model with entities Books and Authors, plus seed data for both.

**🎤 The Prompt:**
```
Create a simple book management data model with entities Books and Authors, plus seed data for both. Do not create services yet.
Create db/schema.cds with namespace my.bookshop:
- Entity Books : cuid, managed { title: String(111) not null, author: Association to Authors, genre: String(111), price: Decimal(9,2), stock: Integer default 0, publishedDate: Date }
- Entity Authors : cuid, managed { name: String(111) not null, dateOfBirth: Date, nationality: String(111), books: Association to many Books on books.author = $self }

Create seed data CSV files in db/data/:
- my.bookshop-Authors.csv — at least 5 authors (Rowling, Orwell, Lee, Fitzgerald, Austen) with ID as simple integers, name, dateOfBirth, nationality
- my.bookshop-Books.csv — at least 8 books across those authors with ID, title, author_ID (matching author IDs), genre, price, stock, publishedDate

```

**💡 What Should Happen:**

This single prompt initiates the creation of your entire data foundation. The AI should create:

- `db/schema.cds` — Core data model with Books and Authors entities
- `db/data/my.bookshop-Authors.csv` — Sample author data
- `db/data/my.bookshop-Books.csv` — Sample book data

**Expected Schema:**
```cds
namespace my.bookshop;

using { Currency, managed, cuid } from '@sap/cds/common';

entity Books : cuid, managed {
  title         : String(111) not null;
  author        : Association to Authors;
  genre         : String(111);
  price         : Decimal(9,2);
  stock         : Integer default 0;
  publishedDate : Date;
}

entity Authors : cuid, managed {
  name         : String(111) not null;
  dateOfBirth  : Date;
  nationality  : String(111);
  books        : Association to many Books on books.author = $self;
}
```

**Key Learning:** Start with high-level domain concepts. AI assistants excel at understanding business domains and creating appropriate data models.

---

### Part 3: Adding Business Logic (⏱️ ~10 - 20  minutes)

**Goal**: Create a BookService that exposes Books and Authors entities with business operations for inventory management, pricing, and analytics.

**🎤 The Prompt:**
```
Create a BookService that exposes the Books and Authors entities and implements: inventory (updateStock, addStock), discounts (applyDiscount), search helpers (getBooksByGenre, getBooksByAuthor), author stats (getAuthorStats), and recommendations (getBookRecommendations).
Create srv/book-service.cds:
- service BookService exposing Books and Authors as projections
- Actions: updateStock(bookId: UUID, quantity: Integer) returns String, addStock(bookId: UUID, quantity: Integer) returns String, applyDiscount(bookId: UUID, discountPercent: Decimal) returns String
- Functions: getBooksByGenre(genre: String) returns array of Books, getBooksByAuthor(authorId: UUID) returns array of Books, getAuthorStats(authorId: UUID) returns { authorName: String, totalBooks: Integer, totalStock: Integer, averagePrice: Decimal }
- Function: getBookRecommendations(userId: String, preferences: String, excludeBookId: UUID) returns { recommendations: array of { bookId: String, title: String, author: String, genre: String, price: Decimal, confidenceScore: Decimal, reason: String }, totalRecommendations: Integer }

Create srv/book-service.js implementing all handlers:
- updateStock: allows positive/negative quantity, prevents stock < 0, returns new level
- addStock: enforces quantity > 0 only, returns new level
- applyDiscount: validates 0–100%, calculates new price, persists it
- getBooksByGenre: LIKE match on genre field
- getBooksByAuthor: filter by author_ID
- getAuthorStats: compute totalBooks, totalStock, averagePrice on demand
- getBookRecommendations: fetches all books from DB (with author expanded), delegates to AI service
- All handlers: proper error handling with 400/404/500, clear messages

```

**💡 What Should Happen:**

The AI expands the basic CRUD service with business operations:

- **Stock Management**: `updateStock` and `addStock` actions
- **Pricing**: `applyDiscount` action with validation
- **Analytics**: `getAuthorStats` function
- **Querying**: `getBooksByGenre` and `getBooksByAuthor` functions

**Expected Service Definition:**
```cds
service BookService {
  entity Books   as projection on my.Books;
  entity Authors as projection on my.Authors;
  
  // Custom actions for Books
  action updateStock(bookId: UUID, quantity: Integer) returns String;
  action addStock(bookId: UUID, quantity: Integer) returns String;
  action applyDiscount(bookId: UUID, discountPercent: Decimal) returns String;
  function getBooksByGenre(genre: String) returns array of Books;
  
  // Custom actions for Authors
  function getAuthorStats(authorId: UUID) returns {
    authorName: String;
    totalBooks: Integer;
    totalStock: Integer;
    averagePrice: Decimal;
  };
  function getBooksByAuthor(authorId: UUID) returns array of Books;
}
```

**Key Learning:** AI can infer common business operations from domain context. Be specific about the type of operations you need (actions vs functions).

---

### Part 4: Integrating AI Capabilities (⏱️ ~20 minutes)

**Goal**: Add AI-powered book recommendations using LiteLLM proxy with a development fallback.

**🎤 The Prompt:**
```
Add AI capabilities for book recommendations using a LiteLLM proxy (OpenAI-compatible chat completions API).
Read connection details from environment variables: LLM_PROXY_HOST, LLM_PROXY_PORT, LLM_MODEL, LLM_API_KEY. Provide a simple development fallback when the proxy isn't running.

Create srv/ai-service.js — class AIRecommendationService:

Configuration (read from env vars):
- LLM_PROXY_HOST (default: http://localhost) — the LiteLLM proxy host URI
- LLM_PROXY_PORT (default: 6655) — the LiteLLM proxy port
- LLM_MODEL (default: gpt-4.1-mini) — model identifier
- LLM_API_KEY (default: 5793d2) — API key for the proxy
- Construct the base URL as: {LLM_PROXY_HOST}:{LLM_PROXY_PORT}

generateRecommendations(userId, preferences, availableBooks):
- If LLM_PROXY_HOST or LLM_PROXY_PORT is not set → fall back to generateMockRecommendations()
- Otherwise, call the LiteLLM proxy using the OpenAI chat completions format:
    POST {LLM_PROXY_HOST}:{LLM_PROXY_PORT}/v1/chat/completions
    Headers: Authorization: Bearer {LLM_API_KEY}, Content-Type: application/json
    Body: {
      "model": "{LLM_MODEL}",
      "messages": [
        {
          "role": "system",
          "content": "You are a book recommendation engine. Given a list of available books and user preferences, return a JSON array of up to 5 recommendations. Each item must have: bookId (string), title (string), author (string), genre (string), price (number), confidenceScore (number 0-1), reason (string, max 100 chars). Return ONLY valid JSON — no markdown, no explanation, just the array."
        },
        {
          "role": "user",
          "content": "User preferences: {preferences}\n\nAvailable books:\n{JSON.stringify(availableBooks)}\n\nReturn your top 5 recommendations as a JSON array."
        }
      ],
      "temperature": 0.7
    }
- Parse the assistant message content as JSON array
- Wrap into { recommendations: [...], totalRecommendations: N }
- On any error (network, parse, etc.) → fall back to generateMockRecommendations()

generateMockRecommendations(preferences, availableBooks):
- Same rule-based fallback as before: keyword matching against title+genre, genre boosting, stock/price scoring, return top 5 with confidenceScore (0–1) and reason strings

Use axios for HTTP calls (already in CAP dependencies, or add it).

MUST DO (LLM-proxy gotchas — apply these up front):
1. Make the chat-completions path configurable via `LLM_PROXY_PATH` (default `/openai/v1/chat/completions` for SAP Hyperspace AI; use `/v1/chat/completions` for a vanilla LiteLLM proxy).
2. Pick a model the proxy actually serves. SAP Hyperspace examples: `gpt-4.1-mini`, `gpt-4.1`, `claude-sonnet-4`.  use a `gpt-4.1*` model unless you know your proxy maps it.
3. Load `.env` via `require('dotenv').config({ override: true })` so values committed in `.env` win over stale shell exports
```

**💡 What Should Happen:**

This prompt triggers creation of the AI integration:

- `srv/ai-service.js` — LiteLLM proxy integration service
- Enhanced `srv/book-service.js` — AI recommendation endpoint
- `.env.example` updated with LLM env vars

**AI Service Features:**
- OpenAI chat completions call to `{LLM_PROXY_HOST}:{LLM_PROXY_PORT}/v1/chat/completions`
- System prompt instructing the model to return structured JSON recommendations
- Fallback mock AI for development (rule-based keyword matching)
- Confidence scoring and reasoning

**Expected AI Integration:**
```javascript
class AIRecommendationService {
  constructor() {
    this.config = {
      host: process.env.LLM_PROXY_HOST || 'http://localhost',
      port: process.env.LLM_PROXY_PORT || '6655',
      model: process.env.LLM_MODEL || 'gpt-4.1-mini',
      apiKey: process.env.LLM_API_KEY || ''
    };
  }
  
  async generateRecommendations(userId, preferences, availableBooks) {
    // Calls LiteLLM proxy with chat completions format
    // Falls back to mock recommendations if proxy unavailable
  }
}
```

**Key Learning:** AI assistants can create integrations with external LLM services. Be specific about the protocol (OpenAI-compatible), env var names, and fallback behavior.

---

### Part 5: Creating the User Interface (⏱️ ~15 minutes)

**Goal**: Create a complete SAP UI5/Fiori application with master-detail views, navigation, and AI recommendations.

**🎤 The Prompt:**
```
Create a SAP UI5/Fiori UI with pages: Main catalog, Book Detail, Author Detail. 
Wire to the OData v4 service, include search + genre filter, dialogs for inventory/discount actions, and a recommendations panel (confidence + short reason)

Ensure to create app/bookshop/ with full SAP UI5 application:

manifest.json:
- sap.app with dataSources pointing to /odata/v4/book/
- Routing: RouteMain (""), RouteBookDetail ("book/{bookId}"), RouteAuthorDetail ("author/{authorId}")
- Models: OData v4 default model

index.html: UI5 bootstrap loading Component.js
Component.js: extends UIComponent, initializes router
model/models.js: createDeviceModel helper

Views & Controllers:
1. App.view.xml + App.controller.js — Shell container with router NavContainer
2. Main.view.xml + Main.controller.js:
   - DynamicPage with SearchField + genre Select filter
   - Table of books showing title, author, genre, price, stock (with status colors)
   - Table of authors showing name, nationality, dateOfBirth
   - Navigation to BookDetail and AuthorDetail on row press
   - Client-side free-text search filtering
   - On RouteMain patternMatched: refresh Books and Authors table bindings to reflect changes from detail pages
3. BookDetail.view.xml + BookDetail.controller.js:
   - Book info display (title, author link, genre, price, stock, publishedDate)
   - "Add Stock" button → Dialog with quantity input → calls addStock action
   - "Apply Discount" button → Dialog with percentage input → calls applyDiscount action
   - Recommendations section → calls getBookRecommendations, displays list with title, confidenceScore bar, reason
   - **Pre-fill the "Your preferences" input with the current book's genre** (read on `dataReceived` of the element binding) so users get one-click recommendations
- **Pass the current `bookId` as `excludeBookId`** so the recommendation list never includes the book the user is already viewing
   - Navigation to author detail on author name press
4. AuthorDetail.view.xml + AuthorDetail.controller.js:
   - Author info (name, dateOfBirth, nationality)
   - Statistics panel calling getAuthorStats (totalBooks, totalStock, averagePrice)
   - Table of author's books with navigation to BookDetail

Create app/bookshop/i18n/i18n.properties with all UI labels.
Create app/bookshop/css/style.css for any custom styling.

MUST DO (UI5 + OData v4 gotchas — apply these up front):
1. Bootstrap UI5 from `https://ui5.sap.com/1.120.0/resources/sap-ui-core.js` (SAPUI5), NOT `sdk.openui5.org`.
2. In `manifest.json` i18n model, set `"supportedLocales": [""]` and `"fallbackLocale": ""` to silence locale-fallback 404s.
3. In every `sap.m.Table` `itemPress` handler, read the row from `oEvent.getParameter("listItem")` — NEVER from `oEvent.getSource()` (that's the Table). Then `getBindingContext()` to get the row context.
4. Call OData v4 actions via `oModel.bindContext("/addStock(...)").setParameter(...).execute()`. Do NOT manually `fetch`/`POST`.
5. Action results returning a primitive arrive wrapped: `getBoundContext().getObject()` → `{ value: "<msg>" }`. Use `result.value` for toasts (otherwise you get `[object Object]`).
```



### Part 6: Creating Documentation (⏱️ ~10 minutes)

#### Part 6a: Generate Architecture Diagram (Optional)

<details>
<summary><strong>Click to expand: Generate architecture diagram using sap-diagram skill</strong></summary>

Before creating the documentation, you can optionally generate a visual architecture diagram using the SAP Diagram skill.

**Goal**: Create a TAM (Fundamental Modeling Concepts) architecture diagram showing system components and their relationships.

**🎤 The Prompt:**
```
Use the sap-diagram skill to create a TAM (Fundamental Modeling Concepts) architecture diagram for this CAP bookshop application.

The diagram should show:
- User (human-agent) interacting with the UI5 App
- UI5 App (agent) communicating with BookService via OData v4
- BookService (agent) connecting to AI Recommendation Service
- AI Service (agent) calling LiteLLM Proxy
- LiteLLM Proxy (agent) routing to gpt-4.1-mini Model (agent)
- BookService performing read/write operations (modify connection) to HANA/SQLite Database (storage) containing Books and Authors entities
- CSV Seed Data (storage) providing initial data load (pointer connection) to the database

Use the TAM track with:
- Agents for active components (services, UI, user)
- Storages for passive data (database, CSV files)
- Channels for request/response communication between agents
- Modify connection for database read/write access
- Pointer connection for seed data initialization

Save the diagram as bookshop-architecture.drawio.svg in the project root.
```

**💡 What Should Happen:**

The AI will:
1. Load the sap-diagram skill from `skills/sap-diagram/`
2. Generate a TAM JSON structure following the Fundamental Modeling Concepts notation
3. Convert it to Draw.io format using the bundled `tam-to-drawio.py` script
4. Export it as an editable SVG file using the Draw.io CLI
5. Clean up intermediate files

**Expected Output:**
- `bookshop-architecture.drawio.svg` — A professional TAM diagram showing the complete system architecture
- The diagram is viewable in any browser and fully editable in Draw.io Desktop

**TAM Notation Reference:**
- **Agents** (sharp rectangles) = Active components that perform operations
- **Storages** (rounded rectangles) = Passive data repositories
- **Channels** (circle with arcs) = Request/response communication paths
- **R>** label = Request direction indicator
- **Modify** (bidirectional arrows) = Read and write data access
- **Pointer** (dashed arrow) = Reference or initialization relationship

</details>

#### Part 6b: Generate Documentation

**Goal**: Create comprehensive testing documentation and architecture overview.

**🎤 The Prompt:**
```
Create a documentation markdown file with step by step instructions to test the app
Create TESTING_GUIDE.md with:
- curl commands for every action/function endpoint (happy path + error cases)
- Expected JSON response shapes
- UI manual test steps (navigation flows, dialog interactions, recommendations)
- Note about LiteLLM proxy needing to be running for real AI recommendations
Create Architecture.md with:
- Detailed architecture specification
- Reference to the bookshop-architecture.drawio.svg diagram if it exists

```

### Part 7: Architecture Review with Custom Skills (⏱️ ~20 minutes, Optional)

<details>


**Goal**: Create a reusable SAP Architect Review skill and use it to audit your completed application for best practices, security, and performance.

#### Step 1: Install the Skill Creator Plugin

First, install the skill-creator plugin which enables you to create custom skills:

```bash
claude plugin install skill-creator@claude-plugins-official
```

#### Step 2: Create the SAP Architect Review Skill

**🎤 The Prompt:**
```
Create a skill to review the current repo as an experienced SAP Architect. The skill should:
- Analyze CAP projects (Node.js and Java), Fiori/UI5 applications, CDS models, OData services
- Check for SAP best practices, naming conventions, proper use of aspects (cuid, managed)
- Evaluate security: authorization annotations, input validation, SQL injection prevention
- Assess performance: N+1 queries, unbounded queries, pagination, caching
- Review architecture: layering, separation of concerns, extensibility
- Provide findings with severity levels (Critical/High/Medium/Low) and effort estimates (XS/S/M/L/XL)
- Output a structured report with executive summary, scorecard, and prioritized recommendations
- Leverage MCP servers (cap-mcp-server, ui5-mcp-server) when available for deeper analysis
```

**💡 What Should Happen:**

The skill-creator will guide you through:
1. Capturing the skill's intent and scope
2. Writing the SKILL.md file with comprehensive review checklists
3. Creating test prompts to verify the skill works
4. Iterating on the skill based on feedback

**Expected Skill Structure:**
```
skills/
└── sap-architect-review/
    ├── SKILL.md              ← Main skill definition
    └── evals/
        └── evals.json        ← Test cases
```

#### Step 3: Use the Skill to Review Your App

Once the skill is created, invoke it to review your completed bookshop application:

**🎤 The Prompt:**
```
Review this CAP project as an SAP Architect. Analyze the data model, services, UI, security, and performance. Provide a prioritized list of findings with recommendations.
```

**💡 Expected Output:**

A comprehensive architecture review report including:

| Section | Content |
|---------|---------|
| **Executive Summary** | Overall health assessment, key strengths, main concerns |
| **Scorecard** | X/10 rating per category (Data Model, Services, UI, Security, Performance, Architecture) |
| **Critical Findings** | 🔴 Issues requiring immediate attention (e.g., missing auth annotations) |
| **High Priority** | 🟠 Important issues for production readiness |
| **Medium Priority** | 🟡 Best practice deviations, maintainability concerns |
| **Low Priority** | 🟢 Enhancement opportunities |
| **Positive Observations** | What the project does well |
| **Next Steps** | Prioritized action items |

**Example Findings the Skill Might Identify:**

```markdown
### 🔴 Critical: Missing Authorization Annotations
- **Location:** srv/book-service.cds
- **Issue:** Service has no @requires or @restrict annotations
- **Impact:** Unauthorized access to all data in production
- **Effort:** S (30 min - 2 hrs)
- **Fix:**
  service BookService @(requires: 'authenticated-user') {
    entity Books @(restrict: [
      { grant: 'READ', to: 'any' },
      { grant: ['UPDATE', 'DELETE'], to: 'admin' }
    ]) as projection on my.Books;
  }
```

**Key Learning:** Custom skills let you codify expert knowledge into reusable workflows. An architecture review skill ensures consistent, thorough assessments across all your SAP projects.

---
</details>

**💡 What Should Happen:**

Comprehensive testing documentation (`TESTING_GUIDE.md`) with:
- Step-by-step testing instructions
- Copy-paste ready curl commands
- Expected JSON responses
- Error scenario testing
- Browser/UI testing instructions
- Note about LiteLLM proxy needing to be running for AI recommendations
- Architecture documentation with diagram reference

**Key Learning:** AI can create comprehensive documentation. Be specific about the audience and format you need.

---


**🎉 Final Result:**

A complete SAP UI5/Fiori application:

**Generated UI Components:**
- `app/bookshop/manifest.json` — Application descriptor with routing and OData v4 integration
- `app/bookshop/index.html` — Application entry point
- `app/bookshop/Component.js` — Main application component

**Views & Controllers:**
- `Main.view.xml` + `Main.controller.js` — Dashboard with books/authors, search, genre filter
- `BookDetail.view.xml` + `BookDetail.controller.js` — Book view with stock/discount dialogs, recommendations
- `AuthorDetail.view.xml` + `AuthorDetail.controller.js` — Author profile with stats and book listings
- `App.view.xml` + `App.controller.js` — Application shell with routing

**UI Features:**
- Responsive master-detail layout
- Advanced search & genre filter
- Stock management and discount dialogs
- AI recommendations with confidence bar and reasoning
- Navigation between books, authors, and details
- Modern SAP Fiori UX with DynamicPage layout

**Expected Routing Configuration:**
<details>
```json
"routing": {
  "routes": [
    {
      "name": "RouteMain",
      "pattern": ":?query:",
      "target": ["TargetMain"]
    },
    {
      "name": "RouteBookDetail", 
      "pattern": "book/{bookId}",
      "target": ["TargetBookDetail"]
    },
    {
      "name": "RouteAuthorDetail",
      "pattern": "author/{authorId}", 
      "target": ["TargetAuthorDetail"]
    }
  ]
}
```
</details>

**Key Learning:** AI can generate complete, production-ready user interfaces with proper architecture, routing, OData v4 integration, and business logic integration.

---

## 🎯 Vibe Coding Best Practices
<details>

### Scope guardrails for this tutorial
- Build only what's in `docs/PRD.md` and `docs/FR.md`
- Do not add: auth, carts, orders, payments, reviews, dashboards beyond author stats, notifications, CI/CD, multi-tenancy, or extra AI features
- If unsure, document the minimal assumption and proceed; do not expand scope

### 1. Start High-Level, Then Drill Down
```
✅ "Create a book management service"
❌ "Write a function to update book stock"
```

### 2. Be Domain-Specific
```
✅ "Add AI capabilities using LiteLLM proxy for book recommendations"
❌ "Add some AI stuff"
```

### 3. Iterate and Refine
```
✅ "Now add validation to the addStock action"
❌ "Make it perfect the first time"
```

### 4. Ask for What You Need
```
✅ "Create documentation with testing instructions"
❌ "Document this somehow"
```

### 5. Leverage AI's Domain Knowledge
```
✅ "Create a CAP service with OData endpoints"
❌ "Create some REST APIs"
```
---
</details>


## 🎓 Working with Skills in Cline/Claude

<details>
<summary><strong>Click to expand: Comprehensive guide to using skills effectively</strong></summary>

Skills are reusable AI workflows that extend your AI assistant's capabilities. Think of them as specialized modes that guide the AI through complex, repeatable tasks with consistent quality.

### What Are Skills?

Skills are markdown-based instruction sets that:
- Guide AI through multi-step workflows (TDD, debugging, documentation)
- Enforce best practices and quality standards
- Provide consistent behavior across sessions
- Can be shared across projects and teams

### Skill Best Practices

#### 1. **Know What Skills Are Available**

Before starting work, check available skills:

```
# In Cline
/skills list

# Or check the skills/ directory
ls skills/
```

Common skill categories:

- **Development workflows**: `tdd-feature-development`, `tdd-bug-fix`
- **Planning & design**: `brainstorming`, `implementation-planner`
- **Quality assurance**: `code-review`, `security-review`
- **Documentation**: `document-generator`, `word-generator`, `powerpoint-generator`
- **SAP-specific**: `sap-diagram`, `sap-ai-core-sdk`, `kubernetes-kyma-helm`
- **Testing**: `webdriverio-testing`, `jmeter-performance-testing`

#### 2. **Invoke Skills Explicitly When Appropriate**

Don't rely on the AI to automatically detect when a skill should be used. Be explicit:

```
✅ Good prompts:
- "Use the brainstorming skill to design the recommendation algorithm"
- "Apply tdd-feature-development to build the discount feature"
- "Use code-review skill to review the book-service.js implementation"

❌ Vague prompts:
- "Let's think about the recommendation algorithm"
- "Build the discount feature"
- "Check if the code looks good"
```

#### 3. **Skills Work Best for Structured Tasks**

Skills excel at tasks with clear phases and quality gates:

**Great for skills:**

- Implementing new features with tests (TDD skills)
- Systematic debugging (debugging skills)
- Creating documentation (doc generator skills)
- Code reviews with checklists (review skills)

**Not ideal for skills:**

- Quick one-line fixes
- Simple questions
- Exploratory "what if" conversations

#### 4. **Combine Skills for Complex Workflows**

Chain skills together for end-to-end workflows:

```
Example workflow for a new feature:

1. "Use brainstorming skill to explore approaches for the AI recommendation integration"
   → Generates design options with tradeoffs

2. "Use tdd-feature-development to implement the chosen approach"
   → Builds feature with comprehensive tests

3. "Use code-review skill to review the implementation"
   → Validates quality and best practices

4. "Use document-generator skill to create API documentation"
   → Produces user-facing docs
```

#### 5. **Understand Skill vs. Prompt Engineering**

| Aspect          | Skills                | Prompt Engineering                       |
|-----------------|-----------------------|------------------------------------------|
| **Purpose**     | Reusable workflows    | One-off instructions                     |
| **Structure**   | Formal, multi-step    | Freeform                                 |
| **Consistency** | High                  | Varies                                   |
| **Best for**    | Repeated tasks        | Unique situations                        |
| **Examples**    | TDD, code review      | "Make this faster", "Add error handling" |

#### 6. **Create Custom Skills for Repeated Patterns**

If you find yourself giving the same complex instructions repeatedly, create a skill:

```
Common scenarios for custom skills:
- Project-specific testing patterns
- Company coding standards enforcement
- Custom documentation formats
- Deployment checklists
- Security compliance workflows
```

Use the `skill-creator:skill-creator` skill to build new skills:

```
"Use skill-creator to build a skill for our CAP service deployment checklist"
```

#### 7. **Skills Should Complement, Not Replace, Your Judgment**

Skills guide the AI but you remain accountable:

- Review skill-generated code before committing
- Adapt skill recommendations to your context
- Override skill suggestions when appropriate
- Use skills as guardrails, not strait-jackets

### Example: Using Skills in This Tutorial

Here's how you might use skills throughout this bookshop tutorial:

**During Part 2 (Data Model):**
```
"Use the brainstorming skill to explore data model options before implementing schema.cds"
```

**During Part 3 (Business Logic):**
```
"Use tdd-feature-development skill to implement the addStock action with proper validation"
```

**During Part 5 (UI):**
```
"Use the brainstorming skill to design the UI navigation structure and component hierarchy"
```

**During Part 6 (Documentation):**
```
"Use document-generator skill to create the TESTING_GUIDE.md with comprehensive test scenarios"
```

**After completion:**
```
"Use code-review skill to review the entire implementation for quality and best practices"
```

### Pro Tips

1. **Skills + MCP = Powerful Combo**: Use skills with MCP tools for context-aware workflows
   - Example: `code-review` skill + `cap-mcp-server` = CAP-aware code reviews

2. **Skills Are Documentation**: Read skill files to learn best practices
   - Skills encode expert knowledge in executable form
   - Great learning resource for unfamiliar domains

3. **Skills Evolve**: Update skills based on lessons learned
   - Capture new best practices
   - Add project-specific checks
   - Refine prompts for better results

4. **Not Everything Needs a Skill**: Use them judiciously
   - Simple tasks: direct prompts
   - Complex workflows: skills
   - Balance structure with flexibility

</details>

---

## 🧪 Testing Your Vibe-Coded App

### Quick Start Testing

#### Backend API Testing
```bash
# Start the service
cds serve

# Test basic functionality
curl -X GET "http://localhost:4004/odata/v4/book/Books"

# Test AI recommendations (requires LiteLLM proxy running)
curl -X GET "http://localhost:4004/odata/v4/book/getBookRecommendations(userId='user123',preferences='fantasy%20magic%20adventure')"

# Test stock management
curl -X POST "http://localhost:4004/odata/v4/book/addStock" \
  -H "Content-Type: application/json" \
  -d '{"bookId": "1", "quantity": 25}'
```

#### UI Testing
```bash
# Start the service with UI
cds serve

# Open the UI application
open http://localhost:4004/bookshop/index.html
```

**UI Testing Checklist:**
- **Browse Books**: Navigate through the book catalog with search and filter
- **View Details**: Click on books to see detailed information and manage stock
- **Author Profiles**: Explore author pages with their complete book collections
- **Stock Management**: Use interactive dialogs to add stock and apply discounts
- **AI Recommendations**: Test the recommendation engine (LiteLLM proxy must be running)
- **Responsive Design**: Test on different screen sizes
- **Real-time Search**: Use the search field to filter books by title, author, or genre

For comprehensive testing instructions, see [TESTING_GUIDE.md](TESTING_GUIDE.md) (generated during Part 6).

---

## 💡 Key Takeaways

1. **Conversation-Driven Development**: Natural language prompts can generate sophisticated applications
2. **Iterative Refinement**: Start broad, then narrow down to specific requirements
3. **Domain Expertise**: AI assistants understand business domains and best practices
4. **Production-Ready Code**: Proper error handling, validation, and documentation are generated automatically
5. **Integration Capabilities**: Complex integrations (like LiteLLM/OpenAI-compatible APIs) can be implemented through conversation

---

## Additional Tips from Coding Experience

_Based on experiences with Cline and Claude Sonnet_

- For all not super-small-tasks, use plan mode first
- Let the AI suggest (multiple) solutions, then choose the best one or correct it
- Tag (`@filepath`) the most relevant files, to make it easier for AI to discover
- Start with planning the basics, then add more features within the run (or split to new session)
- When you're happy with the plan, then let it act out
- Add to your prompt that the AI should not test the solution (doesn't work most of the times)
- If you're refactoring/rewriting, tell the AI to not be backwards compatible (tries this most of the time), just say you're reworking the other parts later
- Be explicit about features and technologies. Tell it features that work already and shouldn't be changed
- Help with bigger refactorings by hand, and do it step by step
- Use custom cline instructions and workflows
- Start over (git is your friend) if it went completely off

---

## 🔍 Troubleshooting

| # | Symptom | Fix |
|---|---------|-----|
| 1 | `cds-serve` → `Cannot find module 'sqlite3'`         | `npm i -D sqlite3` |
| 2 | Blank page; Network shows `sap-ui-core.js` failed     | Bootstrap from `https://ui5.sap.com/1.120.0/resources/sap-ui-core.js` (not `sdk.openui5.org`) |
| 3 | Console 404s on `i18n_en.properties` / `i18n_en_US.properties` | In `manifest.json` i18n model add `"supportedLocales": [""]`, `"fallbackLocale": ""` |
| 4 | Table row clicks don't navigate                       | In `itemPress`: `oEvent.getParameter("listItem").getBindingContext()` — NOT `oEvent.getSource()` |
| 5 | Action toast shows `[object Object]`                  | Unwrap V4 primitive return: `getBoundContext().getObject().value` |
| 6 | OData action returns 500                              | Check `srv/book-service.js` validation; reproduce via the curl in `TESTING_GUIDE.md` |
| 7 | MCP tools not visible in Cline                        | Re-open `cline_mcp_settings.json`; absolute paths required; reload MCP Servers panel |
| 8 | AI recommendations always rule-based, log shows `LLM call failed (401)` | Wrong key, OR shell exports stale `LLM_*` values overriding `.env`. Use `dotenv.config({ override: true })` and put the real key in `.env`. |
| 9 | LLM error: `Invalid model ... gpt-4.1-mini`              | Pick a model the proxy actually serves (e.g. `gpt-4.1-mini` on SAP Hyperspace); set in `.env` as `LLM_MODEL`. |
| 10 | LLM 404 on `/v1/chat/completions`                     | SAP Hyperspace exposes the OpenAI API at `/openai/v1/chat/completions`. Set `LLM_PROXY_PATH=/openai/v1/chat/completions`. |
| 11 | Genre dropdown empty on first page load               | Populate from `attachDataReceived` on the books-table binding (route `patternMatched` fires too early). |
| 12 | Search returns 500 / nothing                          | CAP 8 + SQLite doesn't support `contains(author/name, ...)` in `$filter`. Resolve matching author IDs first via a separate `/Authors` query, then OR `author_ID eq <id>` into the books filter. |

---

## 📖 Learn More

- [SAP CAP Documentation](https://cap.cloud.sap/docs/)
- [LiteLLM Proxy Documentation](https://docs.litellm.ai/)
- [Cline Extension](https://marketplace.visualstudio.com/items?itemName=saoudrizwan.claude-dev)
- [Rate Limits + Other Guidelines](https://ai-docs.portal.hyperspace.tools.sap/llm-proxy/production-use/#rate-limits)
- [Hyperspace Community - Help](https://teams.microsoft.com/l/team/19%3A_sRbyIzWTQfW6BfQNWeiZ_FPIpdnL_LrdNHJBOBj9-I1%40thread.tacv2/conversations?groupId=28a96358-ff3c-48dd-8c2c-2b67778ac532&tenantId=42f7676c-f455-423c-82f6-dc2d99791af7)
- [Hyperspace External MCP Server List](https://ai-docs.portal.hyperspace.tools.sap/mcp-registry/)
- [Internal MCP Server List](https://github.tools.sap/frontrunners/sap-mcp-server-list)
- [Agent Skills Specification](https://agentskills.io/specification)
  
Happy Vibe Coding! 🚀✨
