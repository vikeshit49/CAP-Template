# Coding Standards

Purpose: Produce clear, maintainable code that aligns with CAP/UI5 conventions.

Naming & structure
- Use meaningful names (no 1–2 letter identifiers)
- Keep functions short and single-purpose
- Prefer early returns; avoid deep nesting

Type & data handling
- CAP models: keep entity fields and associations aligned with `db/schema.cds`
- Validate inputs for actions/functions; guard against null/undefined
- Round/format values where PRD/FR specify

Error handling
- Use clear error messages; include actionable context
- Use appropriate HTTP semantics via CAP (e.g., validation vs not found)
- Do not swallow errors; log unexpected failures once at boundary

UI5 practices
- Use XML views + JS controllers; keep controllers slim
- Bind via OData v4 models; avoid manual DOM manipulation
- Show success/error toasts for actions; validate dialog inputs
- Keep routing and model configuration in `manifest.json`

Project specifics
- Do not introduce new entities/pages/features beyond PRD/FR
- Keep recommendation UI minimal: title, confidence, short reason
- Keep search simple: free-text in UI; genre/author helpers via service

Use MCP servers when available
-  Prefer schema-aware MCP tools over raw web search or guesswork. They return validated, version-correct results.
- **`ui5-mcp-server`** — use for any UI5 work:
  - `get_api_reference` to confirm a control/method exists in the target UI5 version and isn't deprecated
  - `run_ui5_linter` to surface deprecated APIs and anti-patterns in `app/`
  - `run_manifest_validation` after editing any `manifest.json`
  - Use BEFORE writing UI5 code, not after, to avoid deprecated APIs
- **`cap-mcp-server`** (a.k.a. `cds-mcp`) — use for any CAP/CDS work:
  - `search_model` to inspect entities, services, annotations, and associations in the loaded model
  - `search_docs` for capire (cap.cloud.sap) best practices on aspects, drafts, auth, query patterns
  - Consult BEFORE adding new entities, projections, or handlers — verifies aspect usage, naming, and patterns
- **`context7`** — use for up-to-date library docs (Express, axios, mocha, ESLint, OpenUI5, Node APIs, etc.):
  - Use when picking versions, finding migration guides, or resolving "is this still the right API?" questions
- Fallback only when the MCP is unavailable (server failed to start) or returns no relevant result. State this in the response so the user knows.
- Do not invent annotations, control names, or library APIs — if MCP can't confirm, look it up explicitly.

