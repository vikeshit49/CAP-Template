# Project Guardrails

Purpose: Keep scope tight and outcomes predictable. Align with the written specs before coding.

Source of truth
- Follow `docs/PRD.md` and `docs/FR.md` strictly. Do not add features/entities/pages beyond scope.
- If something is unclear, propose the minimal assumption and record it in an “Open Questions” note in the PRD. Do not expand scope.

Plan before code (Cline Plan mode)
- Restate the goal and acceptance criteria for this step
- List files to create/edit and why
- Call out validations, error behaviors, edge cases
- Define verification steps (curl/UI) you’ll run after the change
- Only then generate/edit code

Functional expectations
- Backend (CAP): implement actions/functions and validations exactly as specified; keep error semantics simple and consistent
- Frontend (UI5/Fiori): adhere to the pages and flows defined; avoid UI features not in scope
- AI (LiteLLM proxy): integrate per env vars (LLM_PROXY_HOST, LLM_PROXY_PORT, LLM_MODEL, LLM_API_KEY) using OpenAI chat completions format; provide dev fallback as described

Definition of done
- Build runs, lint clean
- Acceptance criteria met
- Tests/steps pass locally
- README and `docs/` updated if behavior changed

